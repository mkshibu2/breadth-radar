@echo off
title Breadth Radar CORS Proxy
color 0b
echo =======================================================
echo     NSE Breadth Radar - Unified Local CORS Proxy
echo =======================================================
echo.

:: Check if Node.js is installed and in PATH
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    color 0c
    echo [ERROR] Node.js is NOT installed or not found in system PATH.
    echo.
    echo To run the local proxy:
    echo  1. Download and install Node.js (LTS version) from:
    echo     https://nodejs.org/
    echo  2. Restart this script after installing.
    echo.
    echo Press any key to open nodejs.org in your browser...
    pause >nul
    start https://nodejs.org/
    exit /b 1
)

:: Check if proxy.js exists in current folder
if not exist "%~dp0proxy.js" (
    color 0c
    echo [ERROR] proxy.js was not found in:
    echo %~dp0
    echo Please ensure proxy.js is in the same folder as this script.
    echo.
    pause
    exit /b 1
)

cd /d "%~dp0"
echo [OK] Node.js detected.
echo Starting Unified CORS Proxy on http://localhost:9090 ...
echo Keep this window open while using the dashboard.
echo.
node proxy.js

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [NOTICE] Proxy server stopped with code %ERRORLEVEL%.
    pause
)
